package game;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import org.jbox2d.dynamics.World;

/**
 * Key handler to control an Walker and shoot with a sound.
 */
public class Controller extends KeyAdapter {
    private static final float JUMPING_SPEED = 8;
    private static final float WALKING_SPEED = 4;
    private GameLevel world;
    private Walker body;
    private WorldView view;
    private SoundClip shout;
    private SoundClip jump;
    FireBall fireball;
  
    /**
     *
     * @param view
     * @param body
     */
    public Controller(WorldView view,Walker body) {
         try {
            shout = new SoundClip("data/throw.mp3");   // Open an audio input stream
            shout.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
         
          try {
            jump = new SoundClip("data/jump.wav");   // Open an audio input stream
            jump.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        
        this.body = body;
        this.view=view;
       
    }

    /**
     *
     * @return body
     */
    public YellowBird getPlayer() {

        return (YellowBird) body;
    }

    /**
     *
     * @return fireball
     */
    public FireBall getFire() {
        return fireball;
    }
    /**
     * Handle key press events for walking and jumping.
     * @param e description of the key event
     */
    @Override
    
    public void keyPressed(KeyEvent e) {
        if (Game.Pause == false){
            
       
        
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_Q) { // Q = quit
            System.exit(0);
            
        } else if (code == KeyEvent.VK_W) { // W = jump
            Vec2 v = body.getLinearVelocity();
            jump.play();
            jump.setVolume(2.0);
            // only jump if body is not already jumping
            if (Math.abs(v.y) < 0.01f) {
                body.jump(JUMPING_SPEED);
            }
        } else if (code == KeyEvent.VK_A) {
            body.startWalking(-WALKING_SPEED); // 1 = walk left
        } else if (code == KeyEvent.VK_D) {
            body.startWalking(WALKING_SPEED); // 2 = walk right
        }
         
        
    }}
   
    
    /**
     * Handle key release events (stop walking) and shoot shurikens with a sound.
     * @param e description of the key event
     */
    @Override
    public void keyReleased(KeyEvent e) {
        
         if (Game.Pause == false){
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_A) {
            body.startWalking(0);
        } else if (code == KeyEvent.VK_D) {
            body.startWalking(0);
        }
         else if (code == KeyEvent.VK_NUMPAD4) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (-40,0));
            fireball.setPosition(new Vec2 ((float) (yolo.x-0.7),yolo.y));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
            shout.play();
        }
        
          else if (code == KeyEvent.VK_NUMPAD6) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (40,0));
            fireball.setPosition(new Vec2 ((float) (yolo.x+1.7),yolo.y));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
            shout.play();
        }
        else if (code == KeyEvent.VK_NUMPAD8) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (0,40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.45), (float) (yolo.y+1.725)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
            shout.play();
            
            
        }
        
          else if (code == KeyEvent.VK_NUMPAD2) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (0,-40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.35), (float) (yolo.y-1.705)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
            shout.play();
            
        }
        else if (code == KeyEvent.VK_NUMPAD7) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (-40,40));
            fireball.setPosition(new Vec2 (yolo.x, (float) (yolo.y+1.725)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
           shout.play();
        }
        
          else if (code == KeyEvent.VK_NUMPAD1) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (-40,-40));
            fireball.setPosition(new Vec2 (yolo.x, (float) (yolo.y-1.705)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
           shout.play();
        }
         else if (code == KeyEvent.VK_NUMPAD9) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
           fireball= new FireBall (view.getWorld());
           fireball.setLinearVelocity(new Vec2 (40,40));
           fireball.setPosition(new Vec2 ((float) (yolo.x+0.7), (float) (yolo.y+1.725)));
           fireball.addCollisionListener(new FireBallActivation(getPlayer()));
           System.out.println("Attack");
           shout.play();
            
        }
        
          else if (code == KeyEvent.VK_NUMPAD3) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (40,-40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.7), (float) (yolo.y-1.75)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            System.out.println("Attack");
            shout.play();
           
        }
        
        else if (code == KeyEvent.VK_NUMPAD5) {
           
            Vec2 yolo=new Vec2();
            yolo = body.getPosition();
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (40,-40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.7), (float) (yolo.y-1.75)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (40,40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.7), (float) (yolo.y+1.725)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (-40,-40));
            fireball.setPosition(new Vec2 (yolo.x, (float) (yolo.y-1.705)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (0,-40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.35), (float) (yolo.y-1.705)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (0,40));
            fireball.setPosition(new Vec2 ((float) (yolo.x+0.45), (float) (yolo.y+1.725)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
           
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (40,0));
            fireball.setPosition(new Vec2 ((float) (yolo.x+1.7),yolo.y));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (-40,0));
            fireball.setPosition(new Vec2 ((float) (yolo.x-0.7),yolo.y));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            fireball= new FireBall (view.getWorld());
            fireball.setLinearVelocity(new Vec2 (-40,40));
            fireball.setPosition(new Vec2 (yolo.x, (float) (yolo.y+1.725)));
            fireball.addCollisionListener(new FireBallActivation(getPlayer()));
            
            System.out.println("Mega Attack");
            shout.play();
            
        }
    }}
    
    /**
     *
     * @param body
     */
    public void setBody(Walker body) {
        this.body = body;
    }
}
