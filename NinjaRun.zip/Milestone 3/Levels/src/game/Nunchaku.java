package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates a nunchaku(weapon)
 * @author Gleb
 */
public class Nunchaku extends DynamicBody {
   
    /**
     * Body parametrs.
     * @param world
     */
    public Nunchaku(World world) {
        super(world);
         Shape nunchakuShape = new PolygonShape (-1.0f,-0.669f, -0.104f,0.747f, 0.081f,0.756f, 1.014f,-0.649f, 0.893f,-0.753f, -0.874f,-0.75f);
        Fixture nunchakufixture = new SolidFixture (this, nunchakuShape);
       addImage(new BodyImage("data/nunchaku.png",2));
    }
}