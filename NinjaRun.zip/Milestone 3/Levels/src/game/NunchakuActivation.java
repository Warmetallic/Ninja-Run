package game;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Collision listener that allows the ninja to collect nunchaku(weapon) with a sound.
 */
public class NunchakuActivation implements CollisionListener {
    private YellowBird ninja;
    private SoundClip pick;
    
    /**
     * Initialize the listener.
     * @param bird
     */
    public NunchakuActivation(YellowBird bird) {
         try {
            pick = new SoundClip("data/pick.wav");   // Open an audio input stream
            
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        this.ninja = bird;
    }

    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() == ninja) {
            pick.play();
            ninja.Nunchaku();
            e.getReportingBody().destroy();
            
        }
    }
    
}