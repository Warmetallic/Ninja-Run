package game;

import city.cs.engine.*;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import org.jbox2d.common.Vec2;

/**
 * Level 2 of the game
 */
public class Level2 extends GameLevel {

    /**
     *
     */
    public YellowBird bird;

    private Torch torch;
    private Stairs stairs;
    private Trap trap;
    private Platform platform; 
    private Spikes spikes;
    private Spikes2 spikes2;
    private Saw saw;
    private Saw2 saw2;
    private Teleport tp;
    private Monster2 monster2;
    private Monster monster;
    
    private Nunchaku nunchaku;
    private Katana katana;
    private Buff buff;
    private Haste haste;
    private static final int NUM_WEAPONS2 = 3;
    /**
     * Populate the world.
     * @param game
     */
    @Override
    public void populate(Game game) {
        super.populate(game);

        { // make the ground
            Shape shape = new BoxShape(11, 0.5f);
            Body ground = new StaticBody(this, shape);
            ground.setPosition(new Vec2(0, -11.5f));
            // walls
            Shape leftWallShape = new BoxShape(0.5f, 20, new Vec2(-11.5f, 5.5f));
            Fixture leftWall = new SolidFixture(ground, leftWallShape);
            Shape rightWallShape = new BoxShape(0.5f, 20, new Vec2(11.5f, 5.5f));
            Fixture rightWall = new SolidFixture(ground, rightWallShape);
            
        }

         { // make a torch
            monster2 = new Monster2(this);
            monster2.setPosition(new Vec2(1, -5));
            monster2.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            monster2.addCollisionListener(new DemonActivation(getFire()));
            monster2.setLinearVelocity(new Vec2 (6,-1));
            
            monster = new Monster(this);
            monster.setPosition(new Vec2(5, 10));
            monster.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            monster.addCollisionListener(new DestroySpike(getFire()));
            
            
            monster = new Monster(this);
            monster.setPosition(new Vec2(-4, 9));
            monster.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            monster.addCollisionListener(new DestroySpike(getFire()));
            
         }
        { // make spikes
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -2.5));
            spikes.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -4.5));
            spikes.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -6.5));
            spikes.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -8.5));
            spikes.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -10.5));
            spikes.addCollisionListener(new SecondLevelRespawn(getPlayer()));
        }
        
        { // make spikes2
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -2, (float) -10));
            spikes2.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -4, (float) -10));
            spikes2.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -6, (float) -10));
            spikes2.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -8, (float) -10));
            spikes2.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 0, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 2, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -2, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -4, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 4, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -6, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 6, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -8, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 8, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 10, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -10, (float) 2.0));
            spikes2.addCollisionListener(new SecondActivation1(getPlayer()));
            spikes2.rotateDegrees(180);
        }
        
        { // make stairs
            stairs = new Stairs(this);
            stairs.setPosition(new Vec2(12, (float) -1.1));
            
        }
        
        { // make a torch
            torch = new Torch(this);
            torch.setPosition(new Vec2(10, 4));
        }
        
        {
            Body orange = new Orange(this); {
                orange.setPosition(new Vec2(7, -9));
                orange.addCollisionListener(new Pickup(getPlayer()));
            }
            { // make a katana
            katana = new Katana(this);
            katana.setPosition(new Vec2((float) -9, (float) -7));
            katana.addCollisionListener(new KatanaActivation(getPlayer()));  
            } 
            
            { // make a katana
            tp = new Teleport(this);
            tp.setPosition(new Vec2((float) -9, (float) 0));
            tp.addCollisionListener(new TeleportActivation(getPlayer()));  
            } 
            
            { // make a leverOrigin
            nunchaku = new Nunchaku(this);
            nunchaku.setPosition(new Vec2((float) 2.5, (float) -1));
            nunchaku.addCollisionListener(new NunchakuActivation(getPlayer()));  
            } 
             
            { // make platform
            platform = new Platform(this);
            platform.setPosition(new Vec2(2, 5));
            platform = new Platform(this);
            platform.setPosition(new Vec2(-7, 8));
            platform = new Platform(this);
            platform.setPosition(new Vec2(3, -2));
            }
            
            { // make a trap
            trap = new Trap(this);
            trap.setPosition(new Vec2((float) 5.5, (float) -7.2));
            trap.addCollisionListener(new SecondLevelRespawn(getPlayer()));
            }
            
            Shape shape = new BoxShape(2, 0.4f);
            Shape shape2 = new BoxShape(0.2f,0.2f);
            Shape shape3 = new BoxShape(11f, 0.5f);
            Body platform1 = new StaticBody(this, shape);
            platform1.setPosition(new Vec2(-8, -7f));
            
            Body platform2 = new StaticBody(this, shape2);// small 
            platform2.setPosition(new Vec2(-2, -6));
            
            Body platform4 = new StaticBody(this, shape2);// small 
            platform4.setPosition(new Vec2(-2, 7));
            
            Body platform3 = new StaticBody(this, shape3);
            platform3.setPosition(new Vec2(0, 1));
        }
        { // make a saw
            saw = new Saw(this);
            saw.setPosition(new Vec2((float) -6, (float) -7));
            saw.addCollisionListener(new SecondLevelRespawn(getPlayer()));
        }
        Door door = new Door(this);
        door.setPosition(new Vec2(-7, 9));
        door.addCollisionListener(new DoorListener(game));
        door.rotateDegrees(-90);
        
        Reset();
    }
    
    /**
     * resets lives and weapons 
     */
    public void Reset() {
        YellowBird.lives = 5;
        YellowBird.weaponCount = 0;
    }
    /** The initial position of the player.
     * @return  */
    @Override
    public Vec2 startPosition() {
        return new Vec2(10, -9);
    }
    /** The position of the exit door.
     * @return  */
    @Override
    public Vec2 doorPosition() {
        return new Vec2(-60,-10);
    }
     /** Is this level complete?
     * @return  */
    @Override
    public boolean isCompleted() {
        return getPlayer().getWeaponCount() == NUM_WEAPONS2;
    }
    }
