package game;

import city.cs.engine.*;

/**
 * Listener for collision with a door.  When the player collides with a door,
 * if the current level is complete the game is advanced to the next level. 
 */
public class DoorListener implements CollisionListener {
    private Game game;
    
    /**
     * Initialize the listener.
     * @param game the component to be given the focus on collide().
     */
    public DoorListener(Game game) {
        this.game = game;
    }

    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
    public void collide(CollisionEvent e) {
        YellowBird player = game.getPlayer();
        if (e.getOtherBody() == player && game.isCurrentLevelCompleted()) {
            System.out.println("Going to next level...");
            game.goNextLevel();
        }
    }
}
