package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *This class is made for a creation of medpack
 * @author Gleb
 */
public class Buff extends DynamicBody {
   
    /**
     * Body parametrs
     * @param world
     */
    public Buff(World world) {
        super(world);
        Shape buffShape = new PolygonShape (-0.47f,-0.499f, -0.469f,0.499f, 0.47f,0.499f, 0.467f,-0.499f);
        Fixture bufffixture = new SolidFixture (this, buffShape);
       addImage(new BodyImage("data/buff.png"));
    }
}