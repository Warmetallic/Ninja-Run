package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates a monster
 * @author Gleb
 */
public class Monster2 extends Walker {
   
    /**
     * Body parametrs.
     * @param world
     */
    public Monster2(World world) {
        super(world);
        Shape MonsterShape = new PolygonShape (-1.02f,-1.98f, -0.78f,1.26f, 0.8f,1.25f, 0.78f,-1.98f);
        Fixture katanafixture = new SolidFixture (this, MonsterShape);
       addImage(new BodyImage("data/1.gif",4));
       
    }

   

    
    
}