/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Creates a platform
 * @author Gleb
 */
public class Platform extends StaticBody {

    boolean setPosition;
    
    /**
     * Body parametrs
     * @param world
     */
    public Platform(World world) {
        super(world);
        
        Shape platformShape = new PolygonShape (-1.34f,-0.17f, -1.27f,-0.27f, 1.27f,-0.29f, 1.32f,-0.21f, 1.34f,0.18f, 1.26f,0.26f, -1.25f,0.26f, -1.34f,0.14f);
        Fixture platformfixture = new SolidFixture (this, platformShape);
        
        addImage(new BodyImage("data/platform.png", 3));
        
        
      
                                  
    }

  

  
   
    
}