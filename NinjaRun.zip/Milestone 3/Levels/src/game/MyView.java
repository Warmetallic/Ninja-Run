/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import city.cs.engine.*;
import java.awt.Color;
import java.awt.Font;

/**
 * extended view
 */
public class MyView extends UserView {
    YellowBird bird;
    
    private Image background;
    
    /**
     *
     * @param world
     * @param bird
     * @param width
     * @param height
     */
    public MyView(World world, YellowBird bird, int width, int height) {
        super(world, width , height);
        this.bird = bird;
        this.background = new ImageIcon("data/qwe.gif").getImage();
       
    }
    
    /**
     *draw an image as a background
     * @param g
     */
    @Override
    protected void paintBackground(Graphics2D g) {
        g.drawImage(background, 0, 0, this);
       
    }
    
    /**
     * Change text color and style
     * Adds paramaters on a background
     * @param g
     */
    @Override
    protected void paintForeground(Graphics2D g) {
        Font myFont  = new Font("TimesRoman", Font.BOLD,   15); 
        g.setFont(myFont);
        g.setColor(Color.red);
       g.drawString("You need to collect 3 weapons " , 40, 20);
       g.drawString("Weapons: " + bird.getWeaponCount()+" out of 3" , 40, 40);
       g.drawString("Lives: " + bird.getHealthCount(), 40, 60);
    }
}
