package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates hasteplatform which increase jump power of the ninja
 * @author Gleb
 */
public class Haste extends StaticBody {
   
    /**
     * Body parametrs.
     * @param world
     */
    public Haste(World world) {
        super(world);
        Shape hasteShape = new PolygonShape (-0.997f,-0.99f, -0.995f,0.997f, 0.987f,0.995f, 0.992f,-0.992f);
        Fixture hastefixture = new SolidFixture (this, hasteShape);
       addImage(new BodyImage("data/haste.png",2));
    }
}