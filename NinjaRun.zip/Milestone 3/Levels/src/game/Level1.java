package game;

import city.cs.engine.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import static java.lang.Math.random;
import javax.swing.JPanel;
import static javax.swing.Spring.height;
import org.jbox2d.common.Vec2;


/**
 * Level 1 of the game
 */
public class Level1 extends GameLevel {
   
    private Torch torch;
    private Stairs stairs;
    private Trap trap;
    private Platform platform; 
    private Spikes spikes;
    private Spikes2 spikes2;
    private Saw saw;
    private Saw2 saw2;
    private Monster monster;
   
    private Nunchaku nunchaku;
    private Katana katana;
    private Buff buff;
    private Haste haste;
    private static final int NUM_WEAPONS = 3;

    /**
     * Populate the world.
     * @param game
     */
    @Override
    public void populate(Game game) {
        super.populate(game);

        { // make the ground
            Shape shape = new BoxShape(11, 0.5f);
            Body ground = new StaticBody(this, shape);
            ground.setPosition(new Vec2(0, -11.5f));
            // walls
            Shape leftWallShape = new BoxShape(0.5f, 15, new Vec2(-11.5f, 5.5f));
            Fixture leftWall = new SolidFixture(ground, leftWallShape);
            Shape rightWallShape = new BoxShape(0.5f, 15, new Vec2(11.5f, 5.5f));
            Fixture rightWall = new SolidFixture(ground, rightWallShape);
        }

        { // make platforms
            Shape shape = new BoxShape(4, 0.5f);
            Body platform1 = new StaticBody(this, shape);
            platform1.setPosition(new Vec2(-7, 5.5f));
            Body platform2 = new StaticBody(this, shape);
            platform2.setPosition(new Vec2(5, -2.5f));
           
            
        }
        
        { // make a torch
            monster = new Monster(this);
            monster.setPosition(new Vec2(-7, 0));
            monster.addCollisionListener(new TrapActivation(getPlayer()));
            monster.addCollisionListener(new DestroySpike(getFire()));
           
             monster = new Monster(this);
             monster.setPosition(new Vec2(7, 6));
             monster.addCollisionListener(new TrapActivation(getPlayer()));
             monster.addCollisionListener(new DestroySpike(getFire()));
        }
        
        { // make a torch
            torch = new Torch(this);
            torch.setPosition(new Vec2(10, -9));
        }
        
        { // make stairs
            stairs = new Stairs(this);
            stairs.setPosition(new Vec2(0, (float) -1.1));
        }
        
        { // make a trap
            trap = new Trap(this);
            trap.setPosition(new Vec2((float) -4.3, (float) -8.5));
            trap.addCollisionListener(new TrapActivation(getPlayer()));
            
        }
         
        
        { // make platform
            platform = new Platform(this);
            platform.setPosition(new Vec2(-3, -4));
            platform = new Platform(this);
            platform.setPosition(new Vec2(0, 5));
            
           
        }
        
        { // make spikes
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -4.5));
            spikes.addCollisionListener(new SpikesActivation(getPlayer()));
        }
        
        { // make spikes2
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 3, (float) -4));

             spikes2.addCollisionListener(new SpikesActivation2(getPlayer()));
             
        }
        
         { // make a saw
            saw = new Saw(this);
            saw.setPosition(new Vec2((float) 0, (float) -2.5));
            saw.addCollisionListener(new SawActivation(getPlayer()));
        }
         
        { // make a saw2
            saw2 = new Saw2(this);
            saw2.setPosition(new Vec2((float) -4, (float) 6));
            saw2.addCollisionListener(new SawActivation2Respawn(getPlayer()));
        }
         
        
        
       
        { // make a leverOrigin
            nunchaku = new Nunchaku(this);
            nunchaku.setPosition(new Vec2((float) -9, (float) -6));
            nunchaku.addCollisionListener(new NunchakuActivation(getPlayer()));  
        } 
        
        { // make a katana
            katana = new Katana(this);
            katana.setPosition(new Vec2((float) 4, (float) -2));
            katana.addCollisionListener(new KatanaActivation(getPlayer()));  
        } 
        
        { // make a buff
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) -3, (float) -3));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
        } 
        
        { // make a haste
            haste = new Haste(this);
            haste.setPosition(new Vec2((float) 7, (float) -1));
            haste.addCollisionListener(new HasteActivation(getPlayer()));  
        } 
        
        {
            Body orange = new Orange(this);
                orange.setPosition(new Vec2(-11, 6));
                orange.addCollisionListener(new Pickup(getPlayer()));
            
        }
    }
/** The initial position of the player.
     * @return  */
    @Override
    public Vec2 startPosition() {
        return new Vec2(2, -10);
    }
/** The position of the exit door.
     * @return  */
    @Override
    public Vec2 doorPosition() {
        return new Vec2((float) 10.4, (float) 5);
    }
 /** Is this level complete?
     * @return  */
    @Override
    public boolean isCompleted() {
        return getPlayer().getWeaponCount() == NUM_WEAPONS;
    }
   
}
