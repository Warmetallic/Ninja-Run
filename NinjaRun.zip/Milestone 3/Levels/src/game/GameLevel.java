package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * A level of the game.
 */
public abstract class GameLevel extends World {
    private YellowBird player;
    private FireBall fireball;
    
    /**
     *
     * @return
     */
    public YellowBird getPlayer() {
        return player;
    }
    
    /**
     *
     * @return
     */
    public FireBall getFire() {
        return fireball;
    }
    /**
     * Populate the world of this level.
     * Child classes should this method with additional bodies.
     * @param game
     */
    public void populate(Game game) {
        player = new YellowBird(this);
        player.setPosition(startPosition());
        Door door = new Door(this);
        door.setPosition(doorPosition());
        door.addCollisionListener(new DoorListener(game));
        
        
        
    }
    
    /** The initial position of the player.
     * @return  */
    public abstract Vec2 startPosition();
    
    /** The position of the exit door.
     * @return  */
    public abstract Vec2 doorPosition();
    
    /** Is this level complete?
     * @return  */
    public abstract boolean isCompleted();

    
}
