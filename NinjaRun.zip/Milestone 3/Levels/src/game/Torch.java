/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Create a torch
 * @author Gleb
 */
public class Torch extends StaticBody {
    
    /**
     * Body parametrs
     * @param w
     */
    public Torch(World w) {
        super(w);
        Shape torchShape = new PolygonShape (0.12f,-2.49f, 0.41f,-0.08f, -0.42f,-0.08f, -0.14f,-2.48f);
        Fixture torchfixture = new SolidFixture (this, torchShape);
        
        Shape torchShape2 = new PolygonShape (0.74f,0.05f, -0.76f,0.06f, -0.94f,0.27f, -0.75f,0.51f, 0.78f,0.51f, 0.93f,0.26f);
        Fixture torch2fixture = new SolidFixture (this, torchShape2);
        
        Shape flameShape = new PolygonShape (-0.17f,0.64f, -0.59f,1.45f, -0.01f,2.5f, 0.61f,1.41f, 0.18f,0.64f);
        Fixture flamefixture = new SolidFixture (this, flameShape);
        
        addImage(new BodyImage("data/torch.png",5));
        
        
    }
    
}
