package game;

import city.cs.engine.*;

/**
 * Collision listener that allows ninja to collect medpack and increase health.
 */
public class BuffActivation implements CollisionListener {
    private YellowBird ninja;
    
    /**
     * Initialize the listener.
     * @param bird the component to be given the focus on collide().
     */
    public BuffActivation(YellowBird bird) {
        this.ninja = bird;
    }

    /**
     * Called when the collision enters a component.
     * @param e description of the listener
     */
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() == ninja) {
            ninja.Buff();
            e.getReportingBody().destroy();
            
        }
    }
    
}