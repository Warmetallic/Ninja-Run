package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * This class made for a creation of a final boss
 * @author Gleb
 */
public class Boss extends Walker {
   
    /**
     *  Body parametrs
     * @param world
     */
    public Boss(World world) {
        super(world);
        Shape BossShape = new PolygonShape (-0.01f,-0.77f, -1.42f,-0.67f, -0.76f,1.7f, 0.53f,1.69f, 1.31f,-0.37f);
        Fixture bossfixture = new SolidFixture (this, BossShape);
       addImage(new BodyImage("data/ghost.gif",5));
       
    }

    
    
}