package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Creates a door which allows ninja to proceed to the the level
 * @author Gleb
 */
public class Door extends StaticBody {

    /**
     * Body parametrs
     * @param world
     */
    public Door(World world) {
        super(world);
        
        Shape baseShape = new PolygonShape (0.66f,-1.08f, 0.66f,0.46f, 0.55f,0.43f, 0.38f,0.26f, 0.39f,-0.91f, 0.56f,-1.08f);
        Fixture basefixture = new SolidFixture (this, baseShape);
        
        Shape base2Shape = new PolygonShape (0.4f,-0.89f, 0.22f,-0.74f, 0.14f,-0.63f, 0.0f,-0.4f, 0.0f,-0.25f, 0.0f,-0.02f, 0.17f,0.13f, 0.38f,0.26f);
        Fixture base2fixture = new SolidFixture (this, base2Shape);
        
        Shape stickShape = new PolygonShape (0.01f,0.0f, -0.63f,0.59f, -0.63f,0.65f, -0.59f,0.68f, 0.12f,0.13f);
        Fixture stickfixture = new SolidFixture (this, stickShape);
        
        
        addImage(new BodyImage("data/leverOrigin.png", 3));
        
        
      
                                  
    }

   

}