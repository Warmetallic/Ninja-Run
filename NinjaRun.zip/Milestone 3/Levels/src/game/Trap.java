/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Create a trap
 * @author Gleb
 */
public class Trap extends StaticBody {
    
    /**
     * Body parametrs
     * @param world
     */
    public Trap(World world) {
        super(world);
        Shape trapShape = new PolygonShape (0.958f,-0.237f, -0.994f,-0.204f, -0.728f,0.243f, 0.704f,0.243f);
        Fixture trapfixture = new SolidFixture (this, trapShape);
        
        addImage(new BodyImage("data/trap.png",(float) 2.3));
        
        
        
    }
    
    
    
}
