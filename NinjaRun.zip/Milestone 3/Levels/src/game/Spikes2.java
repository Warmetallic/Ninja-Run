package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Create spikes
 * @author Gleb
 */
public class Spikes2 extends StaticBody {

    /**
     * Body parametrs
     * @param world
     */
    public Spikes2(World world) {
        super(world);
        
        Shape spikesShape = new PolygonShape (-1.19f,1.3f, -0.93f,-1.42f, -0.64f,1.3f);
        Fixture spikesfixture = new SolidFixture (this, spikesShape);
        
        Shape spikes1Shape = new PolygonShape (-0.7f,1.31f, -0.47f,-1.41f, -0.2f,1.29f);
        Fixture spikes1fixture = new SolidFixture (this, spikes1Shape);
        
        Shape spikes2Shape = new PolygonShape (-0.27f,1.29f, -0.01f,-1.41f, 0.27f,1.29f);
        Fixture spikes2fixture = new SolidFixture (this, spikes2Shape);
        
        Shape spikes3Shape = new PolygonShape (0.25f,1.28f, 0.45f,-1.41f, 0.73f,1.29f);
        Fixture spikes3fixture = new SolidFixture (this, spikes3Shape);
        
        Shape spikes4Shape = new PolygonShape (0.65f,1.3f, 0.92f,-1.43f, 1.19f,1.29f);
        Fixture spikes4fixture = new SolidFixture (this, spikes4Shape);
        
        addImage(new BodyImage("data/spikes.png", 3));
        
        
      
                                  
    }

}