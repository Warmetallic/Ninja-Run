package game;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import city.cs.engine.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jbox2d.common.Vec2;

/**
 *Collision listener that allows demon to die with a sound when player shoots him.
 * @author Gleb
 */
public class DestroySpike implements CollisionListener{

    private FireBall fireball;
    private SoundClip shout;

    /**
     *  Initialize the listener.
     * @param fireball the component to be given the focus on collide().
     */
    public DestroySpike(FireBall fireball) {
       this.fireball=fireball;
       
        try {
            shout = new SoundClip("data/sh.mp3");   // Open an audio input stream
            
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
    }
    
    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
     public void collide(CollisionEvent e) {
        if (e.getOtherBody().getClass() == FireBall.class) {
            shout.play();
            
             e.getReportingBody().destroy();
           System.out.println("You killed a beast");
        }
    }
    
}