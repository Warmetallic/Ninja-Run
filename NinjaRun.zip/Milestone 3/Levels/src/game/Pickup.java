package game;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Collision listener that allows the ninja to collect shuriken(weapon).
 */
public class Pickup implements CollisionListener {
    private YellowBird ninja;
     private SoundClip pick;

    /**
     * Initialize the listener.
     * @param bird the component to be given the focus on collide().
     */
    public Pickup(YellowBird bird) {
         try {
            pick = new SoundClip("data/pick.wav");   // Open an audio input stream
            
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        this.ninja = bird;
    }

    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() == ninja) {
            pick.play();
            ninja.Shuriken();
            e.getReportingBody().destroy();
        }
    }
    
}
