package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Level 3 of the game
 */
public class Level3 extends GameLevel {

    private Boss boss;
    private Torch torch;
    private Stairs stairs;
    private Trap trap;
    private Platform platform; 
    private Spikes spikes;
    private Spikes2 spikes2;
    private Saw saw;
    private Saw2 saw2;
    private Teleport tp;
   
    private Nunchaku nunchaku;
    private Katana katana;
    private Buff buff;
    private Haste haste;
    private static final int NUM_WEAPONS3 = 3;
    /**
     * Populate the world.
     * @param game
     */
    @Override
    public void populate(Game game) {
        super.populate(game);

        { // make the ground
            Shape shape = new BoxShape(11, 0.5f);
            Body ground = new StaticBody(this, shape);
            ground.setPosition(new Vec2(0, -11.5f));
            // walls
            Shape leftWallShape = new BoxShape(0.5f, 20, new Vec2(-11.5f, 5.5f));
            Fixture leftWall = new SolidFixture(ground, leftWallShape);
            Shape rightWallShape = new BoxShape(0.5f, 20, new Vec2(11.5f, 5.5f));
            Fixture rightWall = new SolidFixture(ground, rightWallShape);
            
        }
        {
           boss = new Boss(this);
           boss.setPosition(new Vec2((float) 0.5, (float) -3));
           boss.addCollisionListener(new BossActivation(getFire()));
           boss.addCollisionListener(new ThirdActivation(getPlayer()));
           boss.setGravityScale((float) 0.08);
           
        }
        
        { // make spikes left wall
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -2.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -4.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -6.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -8.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -10.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
             { // make spikes left wall
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -2.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -4.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -6.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -8.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) -10.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            //top level left wall
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) 0));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) 2));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) 4));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) 6));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) -9.25, (float) 8));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
        }
          // make spikes right wall
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) 10, (float) -2.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes.rotateDegrees(180);
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) 10, (float) -4.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes.rotateDegrees(180);
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) 10, (float) -6.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes.rotateDegrees(180);
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) 10, (float) -8.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes.rotateDegrees(180);
            
            spikes = new Spikes(this);
            spikes.setPosition(new Vec2((float) 10, (float) -10.5));
            spikes.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes.rotateDegrees(180);
        
         // make spikes2
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -2, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -4, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -6, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -8, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -10, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            //top level floor
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -2, (float)3));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -4, (float) 3));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -6, (float) 3));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -8, (float) 3));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) -10, (float) 3));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            // make spikes2
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 4, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 6, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 8, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
            
            spikes2 = new Spikes2(this);
            spikes2.setPosition(new Vec2((float) 10, (float) -10));
            spikes2.addCollisionListener(new ThirdActivation(getPlayer()));
            spikes2.rotateDegrees(180);
        
        }
        
     

        {
            Body orange = new Orange(this); {
                orange.setPosition(new Vec2(6, 2));
                orange.addCollisionListener(new Pickup(getPlayer()));
            }
            
            { // make a leverOrigin
            nunchaku = new Nunchaku(this);
            nunchaku.setPosition(new Vec2((float) 8, (float) 2));
            nunchaku.addCollisionListener(new NunchakuActivation(getPlayer()));  
            } 
            
            { // make a katana
            katana = new Katana(this);
            katana.setPosition(new Vec2((float) 10, (float) 2));
            katana.addCollisionListener(new KatanaActivation(getPlayer()));  
            } 
            
            { // make a buff
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 5, (float) 2));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 5, (float) 4));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 5, (float) 6));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 3, (float) 2));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 3, (float) 4));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 3, (float) 6));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 1, (float) 2));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 1, (float) 4));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            
            buff = new Buff(this);
            buff.setPosition(new Vec2((float) 1, (float) 6));
            buff.addCollisionListener(new BuffActivation(getPlayer()));  
            } 
            
            
            
            { // make platform
            platform = new Platform(this);
            platform.setPosition(new Vec2(0, 9));
            platform.rotateDegrees(90);
            
            platform = new Platform(this);
            platform.setPosition(new Vec2(0, 7));
            platform.rotateDegrees(90);
            
            platform = new Platform(this);
            platform.setPosition(new Vec2(0, 5));
            platform.rotateDegrees(90);
            
            platform = new Platform(this);
            platform.setPosition(new Vec2(0, 3.0f));
            platform.rotateDegrees(90);
            
           
            
        }
            
            Shape shape = new BoxShape(2, 0.4f);
            Shape shape2 = new BoxShape(0.2f,0.2f);
            Body platform1 = new StaticBody(this, shape);
            Shape shape3 = new BoxShape(11f, 0.5f);
            platform1.setPosition(new Vec2(-8, -7f));
            
          
            
            Body platform3 = new StaticBody(this, shape3);
            platform3.setPosition(new Vec2(0, 1));
            
            Body platform4 = new StaticBody(this, shape3);
            platform4.setPosition(new Vec2(0, 10.5f));
            
        }
        { // make a saw
            saw = new Saw(this);
            saw.setPosition(new Vec2((float) -2, (float) 5));
            saw.addCollisionListener(new LastSaw(getPlayer()));
            
            saw = new Saw(this);
            saw.setPosition(new Vec2((float) -4, (float) 5));
            saw.addCollisionListener(new LastSaw(getPlayer()));
            
            
            
            
            
            
            saw = new Saw(this);
            saw.setPosition(new Vec2((float) -6, (float) 5));
            saw.addCollisionListener(new LastSaw(getPlayer()));
            
            saw = new Saw(this);
            saw.setPosition(new Vec2((float) -8, (float) 5));
            saw.addCollisionListener(new LastSaw(getPlayer()));
            
            
            
           
          
        }
            { // make a teleport
            tp = new Teleport(this);
            tp.setPosition(new Vec2((float) 3, (float) -5));
            tp.addCollisionListener(new Deathtp(getPlayer()));  
            } 
            
            
            {
            tp = new Teleport(this);
            tp.setPosition(new Vec2((float) -2, (float) -5));
            tp.addCollisionListener(new Wintp(getPlayer()));  
            } 
            Reset();
    }

     /**
     * resets lives and weapons 
     */
    public void Reset() {
        YellowBird.lives = 5;
        YellowBird.weaponCount = 0;
    }
    /** The initial position of the player.
     * @return  */
    @Override
    public Vec2 startPosition() {
        return new Vec2(0, -9);
    }
    /** The position of the exit door.
     * @return  */
    @Override
    public Vec2 doorPosition() {
        return new Vec2(10.5f, 7);
    }
    /** Is this level complete?
     * @return  */
    @Override
    public boolean isCompleted() {
        return getPlayer().getWeaponCount() == NUM_WEAPONS3;
    }
}
