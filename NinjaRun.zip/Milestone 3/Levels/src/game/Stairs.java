package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Create stairs
 * @author Gleb
 */
public class Stairs extends StaticBody {
    
    /**
     * Body parametrs
     * @param w
     */
    public Stairs(World w) {
        super(w);
        Shape stairShape = new PolygonShape (-0.87f,-9.89f, -11.5f,-9.89f, -11.5f,-8.83f, -0.87f,-8.83f);
        Fixture stairfixture = new SolidFixture (this, stairShape);
        
        Shape stair2Shape = new PolygonShape (-11.5f,-8.79f, -3.04f,-8.79f, -3.04f,-7.64f, -11.5f,-7.64f);
        Fixture stair2fixture = new SolidFixture (this, stair2Shape);
        
        Shape stair3Shape = new PolygonShape (-5.24f,-7.64f, -11.5f,-7.64f, -11.5f,-6.62f, -5.24f,-6.62f);
        Fixture stair3fixture = new SolidFixture (this, stair3Shape);
        
        Shape stair4Shape = new PolygonShape (-11.5f,-6.62f, -7.45f,-6.62f, -7.45f,-5.47f, -11.5f,-5.47f);
        Fixture stair4fixture = new SolidFixture (this, stair4Shape);
       
        addImage(new BodyImage("data/stairs.png", 23));
        
        
    }
    
}
