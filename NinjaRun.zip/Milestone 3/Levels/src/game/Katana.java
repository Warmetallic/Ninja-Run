package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates a katana(weapon) 
 * @author Gleb
 */
public class Katana extends DynamicBody {
   
    /**
     * Body parametrs.
     * @param world
     */
    public Katana(World world) {
        super(world);
        Shape katanaShape = new PolygonShape (-0.961f,-0.862f, 0.932f,1.0f, 0.857f,-0.93f, -0.888f,-0.948f);
        Fixture katanafixture = new SolidFixture (this, katanaShape);
       addImage(new BodyImage("data/katana.png",2));
    }
}