package game;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import city.cs.engine.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jbox2d.common.Vec2;

/**
 *Collision listener that allows boss to laugh when ninja shoots him
 * 
 * @author Gleb
 */
public class BossActivation implements CollisionListener{

    private FireBall fireball;
    private SoundClip laugh;
    public static int DamageTaken;
    /**
     * Initialize the listener.
     * @param fireball the component to be given the focus on collide().
     */
    public BossActivation(FireBall fireball) {
       this.fireball=fireball;
       
        try {
            laugh = new SoundClip("data/boss.mp3");   // Open an audio input stream
            
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
    }
    
    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
     public void collide(CollisionEvent e) {
        DamageTaken=5;
        if (e.getOtherBody().getClass() == FireBall.class) {
            
            DamageTaken--;
            laugh.play();
          
           e.getReportingBody().move((new Vec2 ((float) 0, (float) 0.2)));
           System.out.println("You can pass now");
          
        }
        else if (DamageTaken<=0){
               e.getReportingBody().destroy();
           }
    }
    
}