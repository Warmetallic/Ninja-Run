package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates a monster
 * @author Gleb
 */
public class Monster extends StaticBody {
   
    /**
     * Body parametrs.
     * @param world
     */
    public Monster(World world) {
        super(world);
        Shape MonsterShape = new PolygonShape (0.72f,-2.48f, -1.07f,-2.47f, -1.47f,-0.93f, -0.75f,1.41f, 0.53f,1.36f, 1.54f,-0.98f);
        Fixture katanafixture = new SolidFixture (this, MonsterShape);
       addImage(new BodyImage("data/12.gif",5));
       
    }

    
    
}