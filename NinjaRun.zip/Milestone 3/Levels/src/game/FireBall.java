package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates shurikens for shooting
 * @author Gleb
 */
public class FireBall extends DynamicBody {
   
    FireBall fireball;

    /**
     * Body parametrs.
     * @param world 
     */
    public FireBall(World world) {
        super(world);
        
       Shape shape2 = new BoxShape(0.2f,0.2f);
        Fixture bufffixture = new SolidFixture (this, shape2);
       addImage(new BodyImage("data/fireball.png"));
       
      
    }

    

   
    
   
}