package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Creates a saw
 * @author Gleb
 */
public class Saw2 extends StaticBody {

    /**
     * Body parametrs
     * @param world
     */
    public Saw2(World world) {
        super(world);
        
        Shape sawShape = new PolygonShape (-0.04f,-1.28f, 1.09f,-0.7f, 1.15f,0.61f, 0.06f,1.29f, -1.09f,0.72f, -1.13f,-0.61f);
        Fixture sawfixture = new SolidFixture (this, sawShape);
        
        
        
        addImage(new BodyImage("data/saw.png", 3));
        
        
      
                                  
    }

}