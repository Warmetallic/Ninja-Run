package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Creates a shuriken(weapon)
 * @author Gleb
 */
public class Orange extends DynamicBody {
   
    /**
     * Body parametrs.
     * @param world
     */
    public Orange(World world) {
        super(world);
         Shape starShape = new PolygonShape (-0.49f,-0.014f, -0.141f,0.493f, 0.452f,0.337f, 0.48f,-0.264f, -0.076f,-0.488f);
        Fixture starfixture = new SolidFixture (this, starShape);
       addImage(new BodyImage("data/star.png"));
    }
}