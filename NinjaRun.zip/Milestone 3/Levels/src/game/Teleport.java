package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Create a teleport
 * @author Gleb
 */
public class Teleport extends StaticBody {
   
    /**
     * Body parametres
     * @param world
     */
    public Teleport(World world) {
        super(world);
        Shape buffShape = new PolygonShape (-0.47f,-0.499f, -0.469f,0.499f, 0.47f,0.499f, 0.467f,-0.499f);
        Fixture bufffixture = new SolidFixture (this, buffShape);
       addImage(new BodyImage("data/tp.png"));
    }
}
