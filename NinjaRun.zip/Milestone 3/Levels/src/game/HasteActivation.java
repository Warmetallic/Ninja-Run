package game;

import city.cs.engine.*;

/**
 * Collision listener that allows the ninja to increase a jump with a message about it.
 */
public class HasteActivation implements CollisionListener {
    private YellowBird ninja;
    
    /**
     * Initialize the listener.
     * @param bird the component to be given the focus on collide().
     */
    public HasteActivation(YellowBird bird) {
        this.ninja = bird;
    }

    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() == ninja) {
           ninja.Jump();            
           ninja.jump(12);
            
        }
    }
    
}