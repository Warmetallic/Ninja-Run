package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 *Create spikes
 * @author Gleb
 */
public class Spikes extends StaticBody {

    /**
     * Body parametrs
     * @param world
     */
    public Spikes(World world) {
        super(world);
        
        Shape spikesShape = new PolygonShape (-1.72f,-1.18f, -0.46f,-1.06f, -1.72f,-0.92f);
        Fixture spikesfixture = new SolidFixture (this, spikesShape);
        
        Shape spikes1Shape = new PolygonShape (-1.72f,-0.65f, -0.45f,-0.53f, -1.71f,-0.4f);
        Fixture spikes1fixture = new SolidFixture (this, spikes1Shape);
        
        Shape spikes2Shape = new PolygonShape (-1.72f,-0.12f, -0.43f,-0.01f, -1.71f,0.12f);
        Fixture spikes2fixture = new SolidFixture (this, spikes2Shape);
        
        Shape spikes3Shape = new PolygonShape (-1.72f,0.4f, -0.45f,0.53f, -1.71f,0.65f);
        Fixture spikes3fixture = new SolidFixture (this, spikes3Shape);
        
        Shape spikes4Shape = new PolygonShape (-1.72f,0.93f, -0.44f,1.05f, -1.71f,1.18f);
        Fixture spikes4fixture = new SolidFixture (this, spikes4Shape);
        
        addImage(new BodyImage("data/spikes1.png", 3));
        
        
      
                                  
    }

}