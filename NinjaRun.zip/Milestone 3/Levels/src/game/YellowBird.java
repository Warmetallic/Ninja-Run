package game;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import city.cs.engine.*;
import java.io.IOException;
import org.jbox2d.common.Vec2;

/**
 * Main character (ninja)
 */
public class YellowBird extends Walker {

    private SoundClip death;
    private World world;

    /**
     * create variable
     */
    public static int weaponCount;
    
    /**
     * create variable
     */
    public static int lives;
    
    /**
     * Body parametrs.
     * @param world
     */
    public YellowBird(World world) {
        
        super(world);
        Shape headShape = new PolygonShape (0.44f,-0.58f, -0.22f,-0.34f, -0.6f,0.46f, -0.31f,1.2f, 0.52f,1.5f, 1.3f,1.11f, 1.47f,0.21f, 0.84f,-0.55f);
        Fixture headfixture = new SolidFixture (this, headShape);
        
        
        Shape bodyShape = new PolygonShape (0.38f,-1.48f, 1.25f,-1.5f, 1.0f,-0.56f, -0.09f,-0.54f, -0.37f,-1.44f);
        Fixture bodyfixture = new SolidFixture (this, bodyShape);
        
        Shape rightShape = new PolygonShape (1.18f,-1.24f, 1.4f,-1.11f, 1.11f,-0.35f, 0.98f,-0.47f, 1.14f,-1.13f);
        Fixture rightfixture = new SolidFixture (this,rightShape);
        
        Shape leftShape = new PolygonShape (-0.26f,-1.2f, -0.51f,-1.11f, -0.23f,-0.35f, -0.07f,-0.45f, -0.24f,-1.15f);
        Fixture leftfixture = new SolidFixture (this,leftShape);
        
        addImage(new BodyImage("data/ninja-new.png", 3));
        weaponCount = 0;
        lives = 5;
    }
    
    /**
     *
     * @return weaponCount
     */
    public int getWeaponCount() {
        return weaponCount;
    }

    /**
     *
     * @return lives
     */
    public int getHealthCount() {
        if (lives<=0){
         System.exit(0);
         
         
        }
        return lives;
        
    }

    /**
     * print message
     */
    public void Jump() {
        
        System.out.println(" MEGA JUMP!!! ");
    }
    
    /**
     * print message increase lives
     */
    public void Buff() {
        lives++;
        System.out.println("You picked up a medpuck. LIVES = " + lives );
    }
     
    /**
     * print message increase weapons
     */
    public void Shuriken() {
        weaponCount++;
        System.out.println("You picked up a shuriken. Total number of weapons = " + weaponCount );
    }
    
    /**
     * print message increase weapons
     */
    public void Nunchaku() {
        weaponCount++;
        System.out.println("You picked up nunchaku. Total number of weapons = " + weaponCount );
    }

    /**
     * print message increase weapons
     */
    public void Katana() {
        weaponCount++;
        System.out.println("You picked up katana. Total number of weapons = " + weaponCount );
    }

    /**
     * print message decrease lives
     */
    public void Damage() throws IOException {
        try {
            death = new SoundClip("data/death.mp3");   // Open an audio input stream
            death.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        lives--;
        death.play();
        System.out.println("AGONY !!! LIVES = " + lives);
    }

    /**
     * print message decrease lives
     */
    public void Damage1() {
         try {
            death = new SoundClip("data/death.mp3");   // Open an audio input stream
            death.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        lives--;
        death.play();
        System.out.println("PAIN !!! LIVES = " + lives);
    }

    /**
     * print message decrease lives
     */
    public void Damage2() {
         try {
            death = new SoundClip("data/death.mp3");   // Open an audio input stream
            death.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        lives--;
        death.play();
        System.out.println("SUFFERING !!! LIVES = " + lives);
    }

    /**
     * print message decrease lives
     */
    public void Damage3() {
         try {
            death = new SoundClip("data/death.mp3");   // Open an audio input stream
            death.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        lives--;
        death.play();
        System.out.println("INFLICTION !!! LIVES = " + lives); 
    }
    
    /**
     * print message decrease lives
     */
    public void Damage4() {
        try {
            death = new SoundClip("data/death.mp3");   // Open an audio input stream
            death.setVolume(2);
        } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }  
        lives=lives -3;
        death.play();
        System.out.println("ULTRA SUFFERING !!! LIVES = " + lives);
    }

    /**
     * print message
     */
    public void Activation() {
        
        System.out.println("Something happened !!!"); 
    }

   
    }

    

