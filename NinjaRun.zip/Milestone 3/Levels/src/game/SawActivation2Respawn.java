package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Collision listener that allows the ninja to get damage and respawn then he collides with a saw
 * @author Gleb
 */
public class SawActivation2Respawn implements CollisionListener{

    private YellowBird ninja;
    
    /**
     * Initialize the listener.
     * @param bird  the component to be given the focus on collide().
     */
    public SawActivation2Respawn(YellowBird bird) {
        this.ninja = bird;
    }
    
    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
     public void collide(CollisionEvent e) {
        if (e.getOtherBody() == ninja) {
          ninja.Damage2();
          ninja. setPosition(new Vec2((float) 4, (float) -1));
          
           
        }
    }
    
}