package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Collision listener that allows the ninja to teleport.
 */
public class TeleportActivation implements CollisionListener {
    private YellowBird ninja;
    
    /**
     * Initialize the listener.
     * @param bird  the component to be given the focus on collide().
     */
    public TeleportActivation(YellowBird bird) {
        this.ninja = bird;
    }

    /**
     * Called when the collision enters a component.
     * @param e description of listener
     */
    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() == ninja) {
            
            e.getReportingBody().destroy();
            ninja.setPosition(new Vec2(10, 8));
        }
    }
    
}